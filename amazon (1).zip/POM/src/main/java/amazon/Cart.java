package amazon;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


import junit.framework.Assert;

public class Cart {
	
	WebDriver driver;
	public Cart(WebDriver driver) {
		this.driver=driver;
	}
	public HomePage ClickFlipkartLogo() {
		// TODO Auto-generated method stub
		return new HomePage();
	}
	@SuppressWarnings("deprecation")
	public void cartprice() {
		String price1=driver.findElement(By.xpath("//div[@class='s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=MAIN template=SEARCH_RESULTS widgetId=search-results_3']//span[@class='a-price-whole'][normalize-space()='8,999']")).getText();
		String cost1 = price1.replaceAll("[^0-9]", "");
		int conclusion1=Integer.valueOf(cost1);

		String price2=driver.findElement(By.xpath("//span[normalize-space()='6,999']")).getText();
		String cost2 = price2.replaceAll("[^0-9]", "");
		int conclusion2=Integer.valueOf(cost2);

		String price3=driver.findElement(By.xpath("//span[normalize-space()='11,990']")).getText();
		String cost3 = price3.replaceAll("[^0-9]", "");
		int conclusion3=Integer.valueOf(cost3);

		String price4=driver.findElement(By.xpath("//div[@class='s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=MAIN template=SEARCH_RESULTS widgetId=search-results_8']//span[@class='a-price-whole'][normalize-space()='13,999']")).getText();
		String cost4 = price4.replaceAll("[^0-9]", "");
		int conclusion4=Integer.valueOf(cost4);
		System.out.println("The cost of first product is ₹"+conclusion1);
		System.out.println("The cost of second product is ₹"+conclusion2);
		System.out.println("The cost of third product is ₹"+conclusion3);
		System.out.println("The cost of fourth product is ₹"+conclusion4);
		int Sum=conclusion1+conclusion2+conclusion3+conclusion4;
		
		String Summ="₹"+Sum;
		String finalSum=Summ.substring(0,3)+","+Summ.substring(3);
		System.out.println("Subtotal of all products = "+finalSum);
		String price5=driver.findElement(By.xpath("//span[@id='sc-subtotal-amount-buybox']//span[@class='a-size-medium a-color-base sc-price sc-white-space-nowrap']")).getText();
		String cost5 = price5.replaceAll("[^0-9]", "");
		int TotalCart=Integer.valueOf(cost5);
		
		System.out.println("Total Value of Cart = "+price5);
		Assert.assertEquals(Sum, TotalCart);
		if (Sum==TotalCart) {
			System.out.println("Given condition passed");
		}else {
			System.out.println("Given condition failed");
		}
		
	}
	public void quit() {
		driver.quit();
	}
}
