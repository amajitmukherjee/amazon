package amazon;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
public class HomePage {


		WebDriver driver = null;
		public void openBrowser() {
		// TODO Auto-generated method stub
			System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir") + "\\Webdrivers\\chromedriver.exe");
			driver =new ChromeDriver();

		}
		public void openWebsite(){
			driver.get("https://www.amazon.in/");
			driver.manage().window().maximize();

		}
		public void Login() {
			// TODO Auto-generated method stub
			driver.findElement(By.xpath("//span[@id='nav-link-accountList-nav-line-1']")).click();
			driver.findElement(By.xpath("//input[@id='ap_email']")).sendKeys("9063082672");
			driver.findElement(By.xpath("//input[@id='continue']")).click();
			driver.findElement(By.xpath("//input[@id='ap_password']")).sendKeys("Tarun@1362");
			driver.findElement(By.xpath("//input[@id='signInSubmit']")).click();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
						try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}	
		
		public RealmePhonesPage SearchRealme()  {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("mobiles");
			driver.findElement(By.xpath("//input[@id='nav-search-submit-button']")).click();
			
			return PageFactory.initElements(driver, RealmePhonesPage.class);
		}	
		
		

		
}
