package TestCase;

import java.util.ArrayList;
import java.util.Set;
import org.testng.annotations.*;

import amazon.Cart;
import amazon.HomePage;
import amazon.Item1;
import amazon.Item2;
import amazon.Item3;
import amazon.Item4;
import amazon.RealmePhonesPage;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CartValueTest {
	@Test
	public static void main(String[] args) {
		HomePage Home=new HomePage();
		Home.openBrowser();
		Home.openWebsite();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Home.Login();
		//Home.ClickMobile();
		//MobileBrandPage MobileBrand =Home.ClickMobile();
		RealmePhonesPage RealmePage= Home.SearchRealme();
		
		//Phone1.addcart();

		Item1 Phone1= RealmePage.select1();
		Item2 Phone2= RealmePage.select2();
		Item3 Phone3= RealmePage.select3();
		Item4 Phone4= RealmePage.select4();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		RealmePage.driverchange1();
		Phone1.addcart();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		RealmePage.driverchange2();
		Phone2.ClickAddToCart();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		RealmePage.driverchange3();
		Phone3.ClickAddToCart();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		RealmePage.driverchange4();
		Cart value=Phone4.ClickAddToCart();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		value.cartprice();
		value.quit();
}
	
}
